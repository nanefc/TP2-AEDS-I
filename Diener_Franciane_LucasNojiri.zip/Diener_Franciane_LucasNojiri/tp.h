#ifndef TP_H
#define TP_H

char *itoa(int v, char *str, int b);

typedef struct{
	char *Nome;
	float Valor;
} Produto;

typedef struct{
	Produto item;
	int qtdVendida;
} ItemVenda;

typedef struct ListaProduto{
	Produto produto;
	struct ListaProduto *proximo;
} ListaProduto;

void imprimelista(ListaProduto *n);

void imprimeLinha(int a, char b);

void imprimeAEsquerda(char *str, char c, int cont);

void imprimeADireita(char *str, char c, int cont);

void imprimeItemVenda(ItemVenda vend);

void novoProduto(ListaProduto *Np, int *qtd);

int showMenu();

float calcularTotal(ItemVenda vet[], int qtd);

void notaFiscal(ItemVenda vs[], int qtd);

ListaProduto* carregarProdutos(int *qtd);

void gravarProdutos(ListaProduto *Lprod, int qtd);

Produto* buscarProduto(ListaProduto *Lprod, char *produto);

void realizarVenda(ListaProduto *Lprod);




#endif