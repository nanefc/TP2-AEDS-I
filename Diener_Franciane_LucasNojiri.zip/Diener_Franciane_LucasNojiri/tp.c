#include"tp.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>




char *itoa(int v, char *str, int b) {
	char *ret = (char*)malloc(sizeof(50));
	int i;
	for (i = 0; v > 0; i++) {
		ret[i] = v % 10;
		v /= 10;
	}

	int j;

	for (j = 0; j < i; j++)
		str[j] = ret[j];
	str[j] = '\0';

}


//Q02
void imprimeLinha(int a, char b){
	int i = 0;
	for(; i < a; i++){
		printf("%c", b);
	}
}

//Q03
void imprimeAEsquerda(char *str, char c, int cont){
	int i;
	printf("%s", str);
	for(i = strlen(str);i<cont; i++){
		printf("%c", c);
	}
}

void imprimeADireita(char *str, char c, int cont){
	int i;
	i = strlen(str);
	for(; i < cont; i++){
		printf("%c", c);
	}
	printf("%s", str);
}

//Q04
void imprimeItemVenda(ItemVenda vend){
	int tam = 50;
	float subT;
	char str[12], nome[50];
	strcpy(nome, vend.item.Nome);
	
	imprimeAEsquerda(vend.item.Nome, ' ', 30);


	sprintf(str, "%.2f x %d =", vend.item.Valor, vend.qtdVendida); // cria uma string formatada dentro de um vetor
	imprimeADireita(str, ' ', 12);
	subT = vend.item.Valor * vend.qtdVendida;
	sprintf(str, "%.2f", subT);
	imprimeADireita(str, ' ', 8);
	printf("\n");
}

//Q05
void novoProduto(ListaProduto *Np, int *qtd){
	if((*qtd) > 0){
		ListaProduto *pont_aux = Np;
		while(pont_aux -> proximo != NULL)
			pont_aux = pont_aux -> proximo;

		ListaProduto *novo = (ListaProduto*) malloc(sizeof(ListaProduto));
		printf("Digite o Nome do Novo Produto: ");
		novo -> produto.Nome = (char*) malloc(sizeof (char) * 50);
		setbuf(stdin, NULL);
		fgets(novo -> produto.Nome, 50, stdin);
		novo -> produto.Nome[strlen(novo -> produto.Nome)-1] = '\0';
		setbuf(stdin, NULL);
		printf("Digite o Valor do Produto: ");
		scanf("%f", &novo -> produto.Valor);
		setbuf(stdin,NULL);
		(*qtd)++;
		novo -> proximo = NULL;
		pont_aux -> proximo = novo;
	}
	else{

		setbuf(stdin, NULL);
		printf("Digite o Nome do Novo Produto: ");
		Np -> produto.Nome = (char*) malloc(sizeof (char) * 50);
		fgets( Np -> produto.Nome, 50, stdin);
		setbuf(stdin,NULL);
		Np -> produto.Nome[strlen(Np -> produto.Nome)-1] = '\0';
		printf("Digite o Valor do Produto: ");
		scanf("%f", &Np -> produto.Valor);
		setbuf(stdin,NULL);
		(*qtd)++;
	}
}

//Q06
int showMenu(){
	int opcao, c;
	imprimeLinha(50, '*');
	
	printf("\n");
	
	imprimeLinha(18, ' ');
	
	printf("MENU DE OPCOES\n");
	
	imprimeLinha(50, '*');
	
	printf("\n0 - SAIR\n1 - CADASTRAR NOVO PRODUTO\n2 - REALIZAR VENDA\n");
	
	imprimeLinha(50, '*');
	
	printf("\nINFORME A SUA OPCAO: ");
	
	scanf("%d", &opcao);

	return opcao;
}

//Q07
float calcularTotal(ItemVenda vet[], int qtd){
	int i;
	float total = 0;
	for( i = 0; i < qtd; i++){
		total += (vet[i].qtdVendida * vet[i].item.Valor);
	}
	return total;
}

//Q08
void notaFiscal(ItemVenda vs[], int qtd){
	float total;
	char str[50];
	int cont,c,i;
	imprimeLinha(50, '*');
	printf("\n");
	imprimeLinha(21, ' ');
		printf("NOTA FISCAL\n");
	imprimeLinha(50, '*');	
	printf("\n");
	for( i = 0; i < qtd; i++){
		imprimeItemVenda(vs[i]);
	}
	printf("\n");
	imprimeLinha(50, '*');
	total = calcularTotal(vs, qtd);
	printf("\n");
	sprintf(str, "TOTAL: %.2f", total);
	imprimeADireita(str, ' ', 50);
	printf("\n");
	imprimeLinha(50, '.');
	printf("\n\n\n\n");
}

//Q09
ListaProduto* carregarProdutos(int *qtd){
	FILE* pont_arq;
	char str[50];

	pont_arq = fopen("estoque.txt", "r");
	ListaProduto *novo = (ListaProduto*) malloc(sizeof(ListaProduto));
	if(pont_arq == NULL){
		*qtd = 0;
		return novo;
	}
	fscanf(pont_arq, "%f%c%c",  &novo -> produto.Valor, &str[0], &str[0]);
	fgets(str, 50, pont_arq);
	setbuf(pont_arq, NULL);
	novo -> produto.Nome = (char*)malloc(sizeof(char)*50);
	strcpy(novo -> produto.Nome, str);
	novo -> produto.Nome[strlen(novo -> produto.Nome)-1] = '\0';
	
	(*qtd)++;
	novo -> proximo = NULL;
	ListaProduto *pont_aux = novo;

	while(!feof(pont_arq)){  // funcao para indicar o fim do arquivo
		setbuf(pont_arq, NULL);
		ListaProduto *novo = (ListaProduto*) malloc(sizeof(ListaProduto));
		fscanf(pont_arq, "%f%c%c",  &novo -> produto.Valor, &str[0], &str[0]); // funcao para leitura de linhas no arquivo .txt
		if(novo -> produto.Valor == 0.0F) break;
		setbuf(stdin,NULL);
		fgets(str, 50, pont_arq);
		setbuf(pont_arq, NULL);
		novo -> produto.Nome = (char*)malloc(sizeof(char)*50);
		strcpy(novo -> produto.Nome, str);
		novo -> produto.Nome[strlen(novo -> produto.Nome)-1] = '\0';
		(*qtd)++;
		pont_aux -> proximo = NULL;
		pont_aux -> proximo = novo;
		pont_aux = pont_aux->proximo;
	}
	fclose(pont_arq);
	return novo;
}

void gravarProdutos(ListaProduto *Lprod, int qtd){
	int i;
	FILE* pont_arq = fopen("estoque.txt", "w");
	ListaProduto *pont_aux = Lprod;
	for( i = 0; i < qtd; i++){
	fprintf(pont_arq, "%.2f, %s\n", pont_aux -> produto.Valor, pont_aux -> produto.Nome); // funcao para gravar caracteres no arquivo .txt
	pont_aux = pont_aux -> proximo;

	}
	fclose(pont_arq); 
}

//Q10
Produto* buscarProduto(ListaProduto *Lprod, char *produto){
	ListaProduto *pont_aux = Lprod;
	while(pont_aux -> proximo != NULL){
		if (strcmp( pont_aux -> produto.Nome, produto) == 0){
			return &pont_aux->produto.Nome;
		}
		pont_aux = pont_aux -> proximo;
	}
	if (strcmp( pont_aux -> produto.Nome, produto) == 0){
		return &pont_aux->produto.Nome;
	}
	return NULL;
}

//Q11
void realizarVenda(ListaProduto *Lprod){
	char produto[50];
	int qtd=0, i=0;
	ItemVenda prodV[10];
	Produto *p;

	while(1){
		printf("Digite o Nome do Produto: ");
		setbuf(stdin, NULL);
		fgets(produto, 50, stdin);
		produto[strlen(produto)-1] = '\0';
		if(strcmp(produto,"")==0)
			break;
		p=buscarProduto(Lprod,produto);
		if(p==NULL){
			printf("Produto Inexistente!\n");
		continue;
	}

	printf("Digite a Quantidade: ");
	scanf("%d", &qtd);

	prodV[i].qtdVendida = qtd;

	prodV[i].item=*p;

	i++;
	}
		notaFiscal(prodV,i);
	}