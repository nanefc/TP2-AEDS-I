#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"tp.h"

void main(){
	ListaProduto *estoque = NULL;
	int qtd_prod = 0, op;

	estoque = carregarProdutos(&qtd_prod);

	while(1){
	op=showMenu();

		switch(	op){
			case 0:
				gravarProdutos(estoque,qtd_prod);

				return;
				break;

			case 1:
				novoProduto(estoque,&qtd_prod);
				break;

			case 2:
				realizarVenda(estoque);
				break;
		}
	}

}
